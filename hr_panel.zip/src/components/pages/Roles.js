import React from "react";
import Navbar from "../layout/Navbar";
const Roles = () => {
  return (
    <div>
      <Navbar />
      Roles
    </div>
  );
};

export default Roles;
