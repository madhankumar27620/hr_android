import React from "react";
import Navbar from "../layout/Navbar";
const NotFound = () => {
  return (
    <div className="not-found">
      <Navbar />
      <h1 className="display-1">Page Not Found</h1>
    </div>
  );
};

export default NotFound;
