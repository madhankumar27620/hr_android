import React from "react";
import Navbar from "../layout/Navbar";

const About = () => {
  return (
    <div>
      <Navbar />
      About
    </div>
  );
};

export default About;
